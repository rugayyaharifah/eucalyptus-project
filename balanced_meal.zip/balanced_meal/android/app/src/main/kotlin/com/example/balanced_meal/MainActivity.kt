package com.example.balanced_meal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
